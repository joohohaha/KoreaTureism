package com.saem.domain;

public class BReplyVO {
	private int br_num;
	private String m_userid;
	private int b_num;
	private String br_content;
	private int br_used;
	private String br_writedate;
	
	public int getBr_num() {
		return br_num;
	}
	public void setBr_num(int br_num) {
		this.br_num = br_num;
	}
	public String getM_userid() {
		return m_userid;
	}
	public void setM_userid(String m_userid) {
		this.m_userid = m_userid;
	}
	public int getB_num() {
		return b_num;
	}
	public void setB_num(int b_num) {
		this.b_num = b_num;
	}
	public String getBr_content() {
		return br_content;
	}
	public void setBr_content(String br_content) {
		this.br_content = br_content;
	}
	public int getBr_used() {
		return br_used;
	}
	public void setBr_used(int br_used) {
		this.br_used = br_used;
	}
	public String getBr_writedate() {
		return br_writedate;
	}
	public void setBr_writedate(String br_writedate) {
		this.br_writedate = br_writedate;
	}
	
}
